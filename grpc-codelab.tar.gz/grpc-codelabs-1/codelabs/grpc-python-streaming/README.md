# Getting Started with gRPC-Python (Streaming)

Get hands-on with gRPC for Python in this interactive codelab!

Perfect for Python developers new to gRPC, those seeking a refresher, or anyone building distributed
systems. No prior gRPC experience needed!

### How to use this directory

- [start_here](./start_here/) directory serves as a starting point for the codelab.
- [completed](./completed/) directory showcases the finished code, giving you a peak of how the
  final implementation should look like.


## Codelab

Follow the codelab at:
https://codelabs.developers.google.com/grpc/getting-started-grpc-python-streaming
