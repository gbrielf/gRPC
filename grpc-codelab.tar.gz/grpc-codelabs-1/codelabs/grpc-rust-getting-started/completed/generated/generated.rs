#[path = "routeguide.u.pb.rs"]
#[allow(nonstandard_style)]
pub mod internal_do_not_use_routeguide;
#[allow(unused_imports, nonstandard_style)]
pub use internal_do_not_use_routeguide::*;
